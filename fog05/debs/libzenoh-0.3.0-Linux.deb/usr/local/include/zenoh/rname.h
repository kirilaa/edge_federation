#ifndef ZENOH_C_RNAME_H_
#define ZENOH_C_RNAME_H_

int intersect(char *c1, char *c2);

#endif /* ZENOH_C_RNAME_H_ */
