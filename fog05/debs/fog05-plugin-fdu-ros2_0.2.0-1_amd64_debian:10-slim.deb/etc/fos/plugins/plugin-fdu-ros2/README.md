# Eclipse fog05 - Plugin FDU ROS2

This repository container the ROS2 FDU plugin for Eclipse fog05
It allows the deployment of ROS2 application using Eclipse fog05
